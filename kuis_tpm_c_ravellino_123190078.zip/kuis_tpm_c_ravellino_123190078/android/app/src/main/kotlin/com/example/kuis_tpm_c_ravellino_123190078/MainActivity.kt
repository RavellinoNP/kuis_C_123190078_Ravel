package com.example.kuis_tpm_c_ravellino_123190078

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
