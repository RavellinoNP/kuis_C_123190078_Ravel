import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import 'model/movie.dart';

class DetailPage extends StatelessWidget {
  // final Movie movie;
  final int id;
  final String original_language;
  final String original_title;
  final String trailer;
  final String overview;
  final double popularity;
  final String poster_path;
  final String release_date;
  final String title;
  final double vote_average;
  final int vote_count;


  const DetailPage({
    Key? key,
    required this.id,
    required this.original_language,
    required this.original_title,
    required this.trailer,
    required this.overview,
    required this.popularity,
    required this.poster_path,
    required this.release_date,
    required this.title,
    required this.vote_average,
    required this.vote_count,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Page'),
      ),
      body: Container(
        child: Center(
          child: Column(
            children: [
              Image.network(poster_path),
              SizedBox(height: 10,),
              Text(title, style: TextStyle(fontWeight: FontWeight.bold),),
              SizedBox(height: 10,),
              Text("id = ${id}"),
              SizedBox(height: 5),
              Text(trailer,style: TextStyle(fontWeight: FontWeight.bold),),
              SizedBox(height: 10,),
              Text(overview,style: TextStyle(fontWeight: FontWeight.bold),),
              SizedBox(height: 10,),
              Text("popularity = ${popularity}"),
              SizedBox(height: 5,),
            ],
          ),
        ),
      ),
    );
  }
}
